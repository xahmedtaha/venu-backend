<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddChoosenToResturnats extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('resturants', function (Blueprint $table) {
            if (!Schema::hasColumn('resturants', 'choosen')) {
                $table->integer('choosen')->default(0);
            }
            $table->integer('in_offers')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('resturnats', function (Blueprint $table) {
            //
        });
    }
}

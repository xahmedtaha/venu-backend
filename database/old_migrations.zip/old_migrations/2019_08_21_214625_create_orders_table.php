<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('resturant_id');
            $table->unsignedBigInteger('emp_id')->nullable();
            $table->string('voucher')->nullable();
            $table->float('subtotal');
            $table->float('total');
            $table->float('tax')->default(0);
            $table->float('tax_value')->default(0);
            $table->integer('status')->comment("0: pending, 1: preparing, 2: isDelivering, 3: isDelivered");
            $table->string('reject_reason')->nullable();
            $table->string('order_number');
            $table->string('address_id');
            $table->string('lat');
            $table->string('long');
            $table->integer('number_of_products');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateNotifications extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        if (!Schema::hasColumn('notifications', 'resturant_id')) {
            Schema::table('notifications', function (Blueprint $table) {
                $table->unsignedBigInteger('resturant_id')->nullable();
                $table->string('link')->nullable();
                $table->foreign('resturant_id')->references('id')->on('resturants');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

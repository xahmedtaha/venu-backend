<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDescriptionColProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        if (!Schema::hasColumn('products', 'description_ar')) {
            Schema::table('products', function (Blueprint $table) {
                
                $table->string('description_ar');
            });            
        }
        if (!Schema::hasColumn('products', 'description_en')) {
            Schema::table('products', function (Blueprint $table) {
                
                $table->string('description_en');
            });            
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        if (Schema::hasColumn('products', 'description_ar')) {
            Schema::table('products', function (Blueprint $table) {
                
                $table->dropColumn('description_ar');
            });            
        }
        if (Schema::hasColumn('products', 'description_en')) {
            Schema::table('products', function (Blueprint $table) {
                
                $table->dropColumn('description_en');
            });            
        }
    }
}

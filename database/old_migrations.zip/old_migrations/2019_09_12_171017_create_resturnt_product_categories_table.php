<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateResturntProductCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('resturant_product_categories')) 
        {
            Schema::table('resturnt_product_categories', function (Blueprint $table) 
            {
                Schema::create('resturant_product_categories', function (Blueprint $table) {
                    $table->bigIncrements('id');
                    $table->string('name_ar');
                    $table->string('name_en');
                    $table->unsignedBigInteger('resturant_id');
                    $table->foreign('resturant_id')->references('id')->on('resturants')->onDelete('cascade');
                    $table->timestamps();
                });  
            });    
        }
        
        if (!Schema::hasColumn('products', 'category_id')) 
        {
            Schema::table('products', function (Blueprint $table) {
                $table->unsignedBigInteger('category_id');
                $table->foreign('category_id')->references('id')->on('resturant_product_categories');
            });    
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('resturant_product_categories');
    }
}

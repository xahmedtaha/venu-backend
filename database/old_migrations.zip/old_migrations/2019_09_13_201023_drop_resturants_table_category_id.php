<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DropResturantsTableCategoryId extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasColumn('resturants', 'category_id')) 
        {
            Schema::table('resturants', function (Blueprint $table) {
                
                $table->dropForeign('resturants_category_id_foreign');
                $table->dropColumn('category_id');
            });    
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateAddress extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasColumn('addresses', 'city_id')) 
        {
            Schema::table('addresses', function (Blueprint $table) {
                $table->unsignedBigInteger('city_id');
                $table->foreign('city_id')->references('id')->on('cities');
                $table->unsignedBigInteger('place_id')->nullable();
                $table->foreign('place_id')->references('id')->on('places');
            });  
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddForeigns extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() 
    {
        //
        Schema::table('resturants', function (Blueprint $table) {
            $table->foreign('category_id')->references('id')->on('categories');
        });
        Schema::table('products', function (Blueprint $table) {
            $table->foreign('resturant_id')->references('id')->on('resturants');
        });
        Schema::table('orders', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('resturant_id')->references('id')->on('resturants');
            $table->foreign('emp_id')->references('id')->on('employees');
        });
        Schema::table('order_products', function (Blueprint $table) {
            
            $table->foreign('order_id')->references('id')->on('orders');
            $table->foreign('product_id')->references('id')->on('products');
        });
        Schema::table('rates', function (Blueprint $table) {
            
            $table->foreign('resturant_id')->references('id')->on('resturants')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users');
        });
        Schema::table('order_statuses', function (Blueprint $table) {
            
            $table->foreign('order_id')->references('id')->on('orders')->onDelete('cascade');
            $table->foreign('emp_id')->references('id')->on('employees')->onDelete('cascade');
        });
        Schema::table('addresses', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
        Schema::table('resturant_images', function (Blueprint $table) {
            $table->foreign('resturant_id')->references('id')->on('resturants')->onDelete('cascade');
        });
        Schema::table('product_images', function (Blueprint $table) {
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

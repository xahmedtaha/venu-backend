<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class EditNotifications extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (Schema::hasColumn('notifications', 'title')) 
        {
            Schema::table('notifications', function (Blueprint $table) {
                $table->dropColumn('title');
                $table->string('title_ar');
                $table->string('title_en');
                
                $table->dropColumn('text');
                $table->text('description_ar');
                $table->text('description_en');
            });    
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

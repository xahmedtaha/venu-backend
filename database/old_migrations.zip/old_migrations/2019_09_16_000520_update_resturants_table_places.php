<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateResturantsTablePlaces extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasColumn('resturants', 'city_id')&&!Schema::hasColumn('resturants','place_id')) 
        {
            Schema::table('resturants', function (Blueprint $table) {
                $table->unsignedBigInteger('place_id')->nullable();
                $table->unsignedBigInteger('city_id')->nullable();
                $table->foreign('place_id')->references('id')->on('places');
                $table->foreign('city_id')->references('id')->on('cities');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateResturantOwnerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        if (Schema::hasColumn('resturant_owners', 'user_id')) {
            Schema::table('resturant_owners', function (Blueprint $table) {
                // $table->dropForeign(["user_id"]);
                $table->dropColumn("user_id");
                $table->string('name_en');
                $table->renameColumn('name','name_ar');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::table('resturant_owners', function (Blueprint $table) {
            // $table->dropForeign(["user_id"]);
            $table->unsignedBigInteger("user_id");
        });
    }
}

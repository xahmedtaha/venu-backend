<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddDeliveryAndLogoToResturants extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasColumn('resturants', 'delivery_cost')) {
            Schema::table('resturants', function (Blueprint $table) {
                $table->float('delivery_cost')->default(0);
            });
        }

        if (!Schema::hasColumn('resturants', 'logo')) {
            Schema::table('resturants', function (Blueprint $table) {
                $table->string('logo');
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasColumn('resturants', 'delivery_cost')) {
            Schema::table('resturants', function (Blueprint $table) {
                $table->dropColumn('delivery_cost');
            });
        }
        
        if (Schema::hasColumn('resturants', 'logo')) {
            Schema::table('resturants', function (Blueprint $table) {
                $table->dropColumn('logo');
            });
        }
    }
}
